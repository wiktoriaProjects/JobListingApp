﻿namespace JobListingApp.Application.Validators
{
    public class RegisterCreateJobListingDtoValidator
    {

    }
}
