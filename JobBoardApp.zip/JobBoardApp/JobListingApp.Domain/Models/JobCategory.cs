﻿using System.ComponentModel.DataAnnotations;

namespace JobListingApp.Domain.Models
{
    public  class JobCategory
    {
        public int Id { get; set; }
        public string Name { get; set; }

        
    }
}

