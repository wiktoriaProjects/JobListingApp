﻿public class CreateJobCategoryDto
{
    public string Name { get; set; }
    public string Description { get; set; }
}
